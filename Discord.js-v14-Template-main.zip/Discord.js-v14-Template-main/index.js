require("dotenv/config");
const BOT = require("./Structures/bot");
const client = new BOT();

client.init();
