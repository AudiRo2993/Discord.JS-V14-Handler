module.exports = {
  name: "messageDelete",
  /**
   * @param {import("discord.js").Message} message
   * @param {import("../../Structures/bot")} client
   */
  async execute(message, client) {},
};
