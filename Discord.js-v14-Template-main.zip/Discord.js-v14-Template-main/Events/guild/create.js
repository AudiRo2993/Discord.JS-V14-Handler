module.exports = {
  name: "guildCreate",
  /**
   * @param {import("../../Structures/bot")} client
   * @param {import("discord.js").Guild} guild
   */
  async execute(guild, client) {},
};
