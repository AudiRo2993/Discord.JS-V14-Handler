module.exports = {
  name: "guildDelete",
  /**
   * @param {import("../../Structures/bot")} client
   * @param {import("discord.js").Guild} guild
   */
  async execute(guild, client) {},
};
